﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DotNetUI.Models
{
    public class UploadMaster
    {
       // public class InventoryMasterMetaData
       
            

            public string Technology { get; set; }
            [Display(Name = "Support provider")]
            public string Supportprovider { get; set; }
            [Display(Name = "Support Team")]
            public string SupportTeam { get; set; }
            [Display(Name = "Support Classification")]
            public string SupportClass { get; set; }
            [Display(Name = "Business Unit")]
            public string BusinessUnit { get; set; }
            [Display(Name = "Server Short Name")]
            public string ServerShortName { get; set; }
            [Display(Name = "DB Instance")]
            public string DBInstance { get; set; }
            [Display(Name = "Installation Type")]
            public string InstallationType { get; set; }
            [Display(Name = "Env Type")]
            public string EnvType { get; set; }
            [Display(Name = "Application")]
            public string Appl { get; set; }
            [Display(Name = "Database Software Version")]
            public string DbSoftVersion { get; set; }
            [Display(Name = "Database Software Patch Level")]
            public string DbSoftPatchLevl { get; set; }
            [Display(Name = "TNS Names / Connect String")]
            public string TNSNames { get; set; }
            public string Port { get; set; }
            public string AppTier { get; set; }
            [Display(Name = "Cross Charge Cost Center")]
            public string CrossChargeCostCenter { get; set; }
            [Display(Name = "Cost Center Owner")]
            public string CostCenterOwner { get; set; }
            [Display(Name = "Cross Charge ID")]
            public string CrossChargeID { get; set; }
            [Display(Name = "Scope Status (Added/Removed/Baseline)")]
            public string ScopeStatus { get; set; }
            [Display(Name = "Applicable for Bill?")]
            public string ApplicableForBill { get; set; }
            public string SOX { get; set; }
            public string ITGC { get; set; }
            [Display(Name = "Diaster Recovery")]
            public string DiasterRecovery { get; set; }
            [Display(Name = "Notes/history")]
            public string Noteshistory { get; set; }
            [Display(Name = "Decommission Date")]
            
            public String DecommissionDate { get; set; }
            public string Modified { get; set; }
            public string ModifiedBy { get; set; }
            public string Created { get; set; }
            public string CreatedBy { get; set; }
            [Display(Name = "Bkup Monitor")]
            public string BkupMonitor { get; set; }
            [Display(Name = "OEM Deployed")]
            public string OEMDeployed { get; set; }
            [Display(Name = "OEM Tested")]
            public string OEMTested { get; set; }
            [Display(Name = "OSWatcher Deployed")]
            public string OSWatcherDeplyed { get; set; }
            [Display(Name = "Application Contact")]
            public string AppContact { get; set; }
            [Display(Name = "Date of change update")]
            public Nullable<System.DateTime> DateOfChangeUpdate { get; set; }
            public string Hostname { get; set; }
//        }
    }
}