﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DotNetUI.Models
{
    public class TestClass
    {
        public string Technology { get; set; }
        public string Supportprovider { get; set; }
        public string SupportTeam { get; set; }
        public string SupportClass { get; set; }
        public string BusinessUnit { get; set; }
    }
}