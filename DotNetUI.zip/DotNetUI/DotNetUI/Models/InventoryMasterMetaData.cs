﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DotNetUI.Models
{
    public class InventoryMasterMetaData
    {
        public int ID { get; set; }

        public string Technology { get; set; }
        [Display(Name = "Support provider")]
        public string Supportprovider { get; set; }
        [Display(Name = "Support Team")]
        public string SupportTeam { get; set; }
        [Display(Name = "Support Classification")]
        public string SupportClass { get; set; }
        [Display(Name = "Business Unit")]
        public string BusinessUnit { get; set; }
        [Display(Name = "Server")]
        public string ServerShortName { get; set; }
        [Display(Name = "Database Name")]
        public string DBInstance { get; set; }
        [Display(Name = "Installation Type")]
        public string InstallationType { get; set; }
        [Display(Name = "Environment")]
        public string EnvType { get; set; }
        [Display(Name = "Application Name(Unofficial)")]
        public string Appl { get; set; }
        [Display(Name = "Database Software Version")]
        public string DbSoftVersion { get; set; }
        [Display(Name = "Database Software Patch Level")]
        public string DbSoftPatchLevl { get; set; }
        [Display(Name = "TNS Names / Connect String")]
        public string TNSNames { get; set; }
        public string Port { get; set; }
        public string AppTier { get; set; }
        [Display(Name = "Cost Center")]
        public string CrossChargeCostCenter { get; set; }
        [Display(Name = "Cost Center Owner")]
        public string CostCenterOwner { get; set; }
        [Display(Name = "Cross Charge ID")]
        public string CrossChargeID { get; set; }
        [Display(Name = "Scope Status")]
        public string ScopeStatus { get; set; }
        [Display(Name = "Billable")]
        public string ApplicableForBill { get; set; }
        public string SOX { get; set; }
        public string ITGC { get; set; }
        [Display(Name = "Diaster Recovery")]
        public string DiasterRecovery { get; set; }
        [Display(Name = "Notes/history")]
        public string Noteshistory { get; set; }
        [Display(Name = "Decommission Date")]
        [DataType(DataType.DateTime)]
        public DateTime? DecommissionDate { get; set; }
        [NotMapped]
        public string Modified { get; set; }
        public string ModifiedBy { get; set; }
        [NotMapped]
        public string Created { get; set; }
        public string CreatedBy { get; set; }
        [Display(Name = "Bkup Monitor")]
        public string BkupMonitor { get; set; }
        [Display(Name = "OEM Deployed")]
        public string OEMDeployed { get; set; }
        [Display(Name = "OEM Tested")]
        public string OEMTested { get; set; }
        [Display(Name = "OSWatcher Deployed")]
        public string OSWatcherDeplyed { get; set; }
        [Display(Name = "Application Contact")]
        public string AppContact { get; set; }
        [Display(Name = "Date of change update")]
        public Nullable<System.DateTime> DateOfChangeUpdate { get; set; }
        public string Hostname { get; set; }
        [Display(Name = "Azure State")]
        public string AzureState { get; set; }
        public Nullable<bool> Editable { get; set; }
    }

    [MetadataType(typeof(InventoryMasterMetaData))]
    public partial class InventoryMaster
    {
    }
}